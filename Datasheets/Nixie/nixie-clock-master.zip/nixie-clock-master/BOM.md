Power Supply Board
======================

**Resistor**

0.5 ohm * 2

620 ohm * 3

760 ohm * 1

1k ohm * 2

100k ohm * 1

**Electrolytic capacitor**

100uf/16v * 1

33uf/250v * 2

**Mylar capacitor**

1500pf * 1

**Inductor**

22 uf * 1

220 uh * 1

**Diode**

1N4148 * 1

FR157 * 1

**IC**

MC34063A * 1

*BJT**

2SB647(PNP) * 1

**MOSFET**

2SK2611(N-Type) * 1

Display Board
======================

**Nixie tube**

IN-14 * 8

Control Board
======================

**Resistor**

330 ohm * 6

1.8k ohm * 2

4.7k ohm *2

10k ohm * 1

30k ohm * 1

**Electrolytic capacitor**

100uf/16v * 

**Ceramic capacitors**

0.1uf * 2

22pf * 2

**IC**

LM7805 * 1

ATMega328p * 1

TLP521 * 4

HEF428 * 1

K155ID1 * 1

**BJT**

MPSA9(PNP) * 3

**Quartz crystal oscillator**

16MHZ * 1

**Switch**

(2p, 6x6x4.3mm) * 1

**Pin**

(1 * 2 array) * 5

(1 * 4 array) * 2

(2 * 4 array) * 1

(2 * 6 array) * 1
