#ifndef __BUTTON_H
#define __BUTTON_H

void button_status_check();

#endif
