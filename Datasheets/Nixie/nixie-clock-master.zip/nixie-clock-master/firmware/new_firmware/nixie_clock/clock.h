#ifndef __CLOCK_H
#define __CLOCK_H

enum{
  TIME_MODE,
  DATE_MODE,
  //ALARM_MODE,
  MODE_COUNT
};

void clock_display();

#endif
