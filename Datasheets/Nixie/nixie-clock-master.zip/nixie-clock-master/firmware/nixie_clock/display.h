#ifndef __DISPLAY_H__
#define __DISPLAY_H__

void show_number(int num, int digit);
void show_dot(int digit);

#endif
