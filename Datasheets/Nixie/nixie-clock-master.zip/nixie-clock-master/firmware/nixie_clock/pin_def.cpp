//Seven segment font control pin
int font_pinA = 13, font_pinB = 12, font_pinC = 11, font_pinD = 10;
//The dot point of the display
int dot_pin = 9;
//Seven segment digit control pin
int digit_pinA = 8, digit_pinB = 7, digit_pinC = 6;
//Display work status gate
int display_enable_gate = 5;
//Button pin
int btn_search_pin = 4, btn_adjust_pin = 3, btn_mode_pin = 2;
//Bargan music player module
int bargan_tx = 16, bargan_rx = 17;
